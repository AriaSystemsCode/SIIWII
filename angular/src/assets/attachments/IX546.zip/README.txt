﻿Sample export archive for testing ZIP download behavior.
